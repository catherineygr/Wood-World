var Color = Java.type('java.awt.Color');
